
// prefer default export if available
const preferDefault = m => (m && m.default) || m


exports.components = {
  "component---src-pages-404-jsx": preferDefault(require("C:\\Users\\Harm\\Desktop\\138-pyramids-main\\src\\pages\\404.jsx")),
  "component---src-pages-apply-jsx": preferDefault(require("C:\\Users\\Harm\\Desktop\\138-pyramids-main\\src\\pages\\apply.jsx")),
  "component---src-pages-contact-jsx": preferDefault(require("C:\\Users\\Harm\\Desktop\\138-pyramids-main\\src\\pages\\contact.jsx")),
  "component---src-pages-index-jsx": preferDefault(require("C:\\Users\\Harm\\Desktop\\138-pyramids-main\\src\\pages\\index.jsx")),
  "component---src-pages-networks-jsx": preferDefault(require("C:\\Users\\Harm\\Desktop\\138-pyramids-main\\src\\pages\\networks.jsx")),
  "component---src-pages-pyramids-jsx": preferDefault(require("C:\\Users\\Harm\\Desktop\\138-pyramids-main\\src\\pages\\pyramids.jsx")),
  "component---src-pages-story-jsx": preferDefault(require("C:\\Users\\Harm\\Desktop\\138-pyramids-main\\src\\pages\\story.jsx"))
}

